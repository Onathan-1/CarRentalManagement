﻿namespace CarRentalManagement.Domain {
    public class Colour { 
        public string? Name { get; set; }
    }
}
